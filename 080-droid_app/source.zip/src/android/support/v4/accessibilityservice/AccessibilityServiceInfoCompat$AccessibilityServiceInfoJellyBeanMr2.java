// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.accessibilityservice;

import android.accessibilityservice.AccessibilityServiceInfo;

// Referenced classes of package android.support.v4.accessibilityservice:
//            AccessibilityServiceInfoCompatJellyBeanMr2, AccessibilityServiceInfoCompat

static class q extends q
{

    public int getCapabilities(AccessibilityServiceInfo accessibilityserviceinfo)
    {
        return AccessibilityServiceInfoCompatJellyBeanMr2.getCapabilities(accessibilityserviceinfo);
    }

    q()
    {
    }
}
