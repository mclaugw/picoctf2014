// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view;

import android.view.View;
import android.view.animation.Interpolator;

// Referenced classes of package android.support.v4.view:
//            ViewPropertyAnimatorCompat, ViewPropertyAnimatorListener

static class 
    implements 
{

    public void alpha(View view, float f)
    {
    }

    public void alphaBy(View view, float f)
    {
    }

    public void cancel(View view)
    {
    }

    public long getDuration(View view)
    {
        return 0L;
    }

    public Interpolator getInterpolator(View view)
    {
        return null;
    }

    public long getStartDelay(View view)
    {
        return 0L;
    }

    public void rotation(View view, float f)
    {
    }

    public void rotationBy(View view, float f)
    {
    }

    public void rotationX(View view, float f)
    {
    }

    public void rotationXBy(View view, float f)
    {
    }

    public void rotationY(View view, float f)
    {
    }

    public void rotationYBy(View view, float f)
    {
    }

    public void scaleX(View view, float f)
    {
    }

    public void scaleXBy(View view, float f)
    {
    }

    public void scaleY(View view, float f)
    {
    }

    public void scaleYBy(View view, float f)
    {
    }

    public void setDuration(View view, long l)
    {
    }

    public void setInterpolator(View view, Interpolator interpolator)
    {
    }

    public void setListener(View view, ViewPropertyAnimatorListener viewpropertyanimatorlistener)
    {
    }

    public void setStartDelay(View view, long l)
    {
    }

    public void start(View view)
    {
    }

    public void translationX(View view, float f)
    {
    }

    public void translationXBy(View view, float f)
    {
    }

    public void translationY(View view, float f)
    {
    }

    public void translationYBy(View view, float f)
    {
    }

    public void withEndAction(View view, Runnable runnable)
    {
        runnable.run();
    }

    public void withLayer(View view)
    {
    }

    public void withStartAction(View view, Runnable runnable)
    {
        runnable.run();
    }

    public void x(View view, float f)
    {
    }

    public void xBy(View view, float f)
    {
    }

    public void y(View view, float f)
    {
    }

    public void yBy(View view, float f)
    {
    }

    ()
    {
    }
}
